﻿Namespace Classes
    Public Class DatabaseAndTables
        Public Property DatabaseName() As String
        Public Property TableNameList() As List(Of String)
    End Class
End Namespace