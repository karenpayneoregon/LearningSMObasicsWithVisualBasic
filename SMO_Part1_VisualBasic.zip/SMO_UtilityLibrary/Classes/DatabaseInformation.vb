﻿Imports Microsoft.SqlServer.Management.Smo
Imports Microsoft.SqlServer.SmoExtended

Namespace Classes
    Public Class DatabaseInformation

        ''' <summary>
        ''' Get database on default server
        ''' </summary>
        ''' <param name="pDatabaseName">Database name</param>
        ''' <returns></returns>
        Public Function GetDatabase(pDatabaseName As String) As DatabaseDetails
            Dim result As New DatabaseDetails With {.Exists = False}
            Dim srv = New Server
            Dim db = srv.Databases(pDatabaseName)

            If db IsNot Nothing Then
                result.Exists = True
                result.Name = pDatabaseName
                result.Database = db
            End If

            Return result

        End Function
        ''' <summary>
        ''' Using the default server copy one database to a new database with tables,
        ''' data, primary keys
        ''' </summary>
        ''' <param name="pOriginalDatabase">Existing database</param>
        ''' <param name="pNewDatabase">Non-existing database</param>
        ''' <returns>True on successully completing the copy, false on failure</returns>
        Public Function CopyDatabase(pOriginalDatabase As String, pNewDatabase As String) As Boolean
            Dim srv As Server = New Server
            Dim db As Database

            Try
                db = srv.Databases(pOriginalDatabase)
                Dim dbCopy As Database
                dbCopy = New Database(srv, pNewDatabase)
                dbCopy.Create()

                Dim xfr As Transfer
                xfr = New Transfer(db)
                xfr.CopyAllTables = True
                xfr.Options.WithDependencies = True
                xfr.Options.ContinueScriptingOnError = True
                xfr.DestinationDatabase = pNewDatabase
                xfr.DestinationServer = srv.Name
                xfr.DestinationLoginSecure = True
                xfr.Options.DriAllKeys = True
                xfr.CopySchema = True

                xfr.TransferData()
                Return True
            Catch ex As Exception
                Return False
            End Try

        End Function
        ''' <summary>
        ''' Get database on specified server
        ''' </summary>
        ''' <param name="pServer">Server name</param>
        ''' <param name="pDatabaseName">Database name</param>
        ''' <returns></returns>
        Public Function GetDatabase(pServer As String, pDatabaseName As String) As DatabaseDetails

            Dim result As New DatabaseDetails With {.Exists = False}
            Dim srv = New Server(pServer)
            Dim db = srv.Databases(pDatabaseName)

            If db IsNot Nothing Then
                result.Exists = True
                result.Name = pDatabaseName
                result.Database = db
            End If

            Return result

        End Function
        ''' <summary>
        ''' Get table names using the default server and database name
        ''' </summary>
        ''' <param name="pDatabaseName">Existing database in pServer</param>
        ''' <returns>TableDetails object indicating if there the database exists and has tables</returns>
        Public Function TableNames(pDatabaseName As String) As TableDetails

            Dim result As New TableDetails With {.Exists = False, .DatabaseName = pDatabaseName}
            Dim srv = New Server()
            Dim database = srv.Databases(pDatabaseName)

            If database IsNot Nothing Then

                result.ServerName = srv.Name
                result.Exists = True

                result.NameList = database.Tables.OfType(Of Table)().
                    Where(Function(tbl) (Not tbl.IsSystemObject)).
                    Select(Function(tbl) tbl.Name).ToList()

            End If

            Return result

        End Function
        ''' <summary>
        ''' Get table names using a named server and database name
        ''' </summary>
        ''' <param name="pServer">Available SQL-Server name</param>
        ''' <param name="pDatabaseName">Existing database in pServer</param>
        ''' <returns>TableDetails object indicating if there the database exists and has tables</returns>
        Public Function TableNames(pServer As String, pDatabaseName As String) As TableDetails

            Dim result As New TableDetails With {.Exists = False, .ServerName = pServer, .DatabaseName = pDatabaseName}
            Dim srv = New Server(pServer)
            Dim database = srv.Databases(pDatabaseName)

            If database IsNot Nothing Then

                result.Exists = True

                result.NameList = database.Tables.OfType(Of Table)().
                    Where(Function(tbl) (Not tbl.IsSystemObject)).
                    Select(Function(tbl) tbl.Name).ToList()


            End If

            Return result

        End Function
    End Class
End Namespace