﻿Namespace Interfaces
    Public Interface IDetails
        Property Exists() As Boolean
        Property Name() As String
    End Interface
End Namespace