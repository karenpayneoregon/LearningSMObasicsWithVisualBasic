﻿namespace SMO_Library
{
    public class LocalServer
    {
        public string ServerName { get; set; }
        public string Name { get; set; }
        public string Instance { get; set; }
    }
}
